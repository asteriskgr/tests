using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Bornander.UI.ScrollBar.Test
{
    public partial class TestForm : Form
    {
        public TestForm()
        {
            InitializeComponent();
            marqueeTimer.Enabled = true;
        }

        private void menuItemExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void trackBar1_ValueChanged_1(object sender, EventArgs e)
        {
            progressBar1.Value = trackBar1.Value;
            progressBar2.Value = trackBar1.Value;
            progressBar3.Value = trackBar1.Value;
            progressBar5.Value = trackBar1.Value;
        }

        private void marqueeTimer_Tick(object sender, EventArgs e)
        {
            progressBar4.MarqueeUpdate();
            progressBar6.MarqueeUpdate();
            progressBar8.MarqueeUpdate();
            progressBar9.MarqueeUpdate();
            progressBar10.MarqueeUpdate();
        }
    }
}