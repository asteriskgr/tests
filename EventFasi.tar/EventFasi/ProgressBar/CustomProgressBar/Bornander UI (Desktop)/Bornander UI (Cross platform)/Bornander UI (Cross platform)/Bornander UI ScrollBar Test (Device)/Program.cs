using System;
using System.Windows.Forms;

namespace Bornander.UI.ScrollBar.Test
{
    static class Program
    {
        [MTAThread]
        static void Main()
        {
            Application.Run(new TestForm());
        }
    }
}