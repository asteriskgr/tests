namespace Bornander.UI.ScrollBar.Test
{
    partial class TestForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TestForm));
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.menuItemFile = new System.Windows.Forms.MenuItem();
            this.menuItemExit = new System.Windows.Forms.MenuItem();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.progressBar1 = new Bornander.UI.ProgressBar.ProgressBar();
            this.progressBar2 = new Bornander.UI.ProgressBar.ProgressBar();
            this.progressBar3 = new Bornander.UI.ProgressBar.ProgressBar();
            this.progressBar5 = new Bornander.UI.ProgressBar.ProgressBar();
            this.progressBar4 = new Bornander.UI.ProgressBar.ProgressBar();
            this.progressBar6 = new Bornander.UI.ProgressBar.ProgressBar();
            this.progressBar8 = new Bornander.UI.ProgressBar.ProgressBar();
            this.progressBar9 = new Bornander.UI.ProgressBar.ProgressBar();
            this.progressBar10 = new Bornander.UI.ProgressBar.ProgressBar();
            this.marqueeTimer = new System.Windows.Forms.Timer();
            this.SuspendLayout();
            // 
            // mainMenu1
            // 
            this.mainMenu1.MenuItems.Add(this.menuItemFile);
            // 
            // menuItemFile
            // 
            this.menuItemFile.MenuItems.Add(this.menuItemExit);
            this.menuItemFile.Text = "File";
            // 
            // menuItemExit
            // 
            this.menuItemExit.Text = "Exit";
            this.menuItemExit.Click += new System.EventHandler(this.menuItemExit_Click);
            // 
            // trackBar1
            // 
            this.trackBar1.Location = new System.Drawing.Point(197, 3);
            this.trackBar1.Maximum = 100;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBar1.Size = new System.Drawing.Size(40, 248);
            this.trackBar1.TabIndex = 1;
            this.trackBar1.TickFrequency = 5;
            this.trackBar1.ValueChanged += new System.EventHandler(this.trackBar1_ValueChanged_1);
            // 
            // progressBar1
            // 
            this.progressBar1.BackgroundDrawMethod = Bornander.UI.ProgressBar.ProgressBar.DrawMethod.Stretch;
            this.progressBar1.BackgroundLeadingSize = 12;
            this.progressBar1.BackgroundPicture = ((System.Drawing.Image)(resources.GetObject("progressBar1.BackgroundPicture")));
            this.progressBar1.BackgroundTrailingSize = 12;
            this.progressBar1.ForegroundDrawMethod = Bornander.UI.ProgressBar.ProgressBar.DrawMethod.Tile;
            this.progressBar1.ForegroundLeadingSize = 0;
            this.progressBar1.ForegroundPicture = ((System.Drawing.Image)(resources.GetObject("progressBar1.ForegroundPicture")));
            this.progressBar1.ForegroundTrailingSize = 0;
            this.progressBar1.Location = new System.Drawing.Point(5, 3);
            this.progressBar1.Marquee = Bornander.UI.ProgressBar.ProgressBar.MarqueeStyle.TileWrap;
            this.progressBar1.MarqueeWidth = 10;
            this.progressBar1.Maximum = 100;
            this.progressBar1.Minimum = 0;
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.OverlayDrawMethod = Bornander.UI.ProgressBar.ProgressBar.DrawMethod.Stretch;
            this.progressBar1.OverlayLeadingSize = 12;
            this.progressBar1.OverlayPicture = ((System.Drawing.Image)(resources.GetObject("progressBar1.OverlayPicture")));
            this.progressBar1.OverlayTrailingSize = 12;
            this.progressBar1.Size = new System.Drawing.Size(187, 23);
            this.progressBar1.Type = Bornander.UI.ProgressBar.ProgressBar.BarType.Progress;
            this.progressBar1.Value = 0;
            // 
            // progressBar2
            // 
            this.progressBar2.BackgroundDrawMethod = Bornander.UI.ProgressBar.ProgressBar.DrawMethod.Tile;
            this.progressBar2.BackgroundLeadingSize = 0;
            this.progressBar2.BackgroundPicture = ((System.Drawing.Image)(resources.GetObject("progressBar2.BackgroundPicture")));
            this.progressBar2.BackgroundTrailingSize = 0;
            this.progressBar2.ForegroundDrawMethod = Bornander.UI.ProgressBar.ProgressBar.DrawMethod.Tile;
            this.progressBar2.ForegroundLeadingSize = 0;
            this.progressBar2.ForegroundPicture = ((System.Drawing.Image)(resources.GetObject("progressBar2.ForegroundPicture")));
            this.progressBar2.ForegroundTrailingSize = 0;
            this.progressBar2.Location = new System.Drawing.Point(5, 61);
            this.progressBar2.Marquee = Bornander.UI.ProgressBar.ProgressBar.MarqueeStyle.TileWrap;
            this.progressBar2.MarqueeWidth = 10;
            this.progressBar2.Maximum = 100;
            this.progressBar2.Minimum = 0;
            this.progressBar2.Name = "progressBar2";
            this.progressBar2.OverlayDrawMethod = Bornander.UI.ProgressBar.ProgressBar.DrawMethod.Stretch;
            this.progressBar2.OverlayLeadingSize = 4;
            this.progressBar2.OverlayPicture = null;
            this.progressBar2.OverlayTrailingSize = 4;
            this.progressBar2.Size = new System.Drawing.Size(187, 17);
            this.progressBar2.Type = Bornander.UI.ProgressBar.ProgressBar.BarType.Progress;
            this.progressBar2.Value = 0;
            // 
            // progressBar3
            // 
            this.progressBar3.BackgroundDrawMethod = Bornander.UI.ProgressBar.ProgressBar.DrawMethod.Stretch;
            this.progressBar3.BackgroundLeadingSize = 12;
            this.progressBar3.BackgroundPicture = ((System.Drawing.Image)(resources.GetObject("progressBar3.BackgroundPicture")));
            this.progressBar3.BackgroundTrailingSize = 12;
            this.progressBar3.ForegroundDrawMethod = Bornander.UI.ProgressBar.ProgressBar.DrawMethod.Stretch;
            this.progressBar3.ForegroundLeadingSize = 12;
            this.progressBar3.ForegroundPicture = ((System.Drawing.Image)(resources.GetObject("progressBar3.ForegroundPicture")));
            this.progressBar3.ForegroundTrailingSize = 12;
            this.progressBar3.Location = new System.Drawing.Point(5, 103);
            this.progressBar3.Marquee = Bornander.UI.ProgressBar.ProgressBar.MarqueeStyle.TileWrap;
            this.progressBar3.MarqueeWidth = 10;
            this.progressBar3.Maximum = 100;
            this.progressBar3.Minimum = 0;
            this.progressBar3.Name = "progressBar3";
            this.progressBar3.OverlayDrawMethod = Bornander.UI.ProgressBar.ProgressBar.DrawMethod.Stretch;
            this.progressBar3.OverlayLeadingSize = 12;
            this.progressBar3.OverlayPicture = ((System.Drawing.Image)(resources.GetObject("progressBar3.OverlayPicture")));
            this.progressBar3.OverlayTrailingSize = 12;
            this.progressBar3.Size = new System.Drawing.Size(187, 21);
            this.progressBar3.Type = Bornander.UI.ProgressBar.ProgressBar.BarType.Progress;
            this.progressBar3.Value = 0;
            // 
            // progressBar5
            // 
            this.progressBar5.BackgroundDrawMethod = Bornander.UI.ProgressBar.ProgressBar.DrawMethod.Tile;
            this.progressBar5.BackgroundLeadingSize = 0;
            this.progressBar5.BackgroundPicture = ((System.Drawing.Image)(resources.GetObject("progressBar5.BackgroundPicture")));
            this.progressBar5.BackgroundTrailingSize = 0;
            this.progressBar5.ForegroundDrawMethod = Bornander.UI.ProgressBar.ProgressBar.DrawMethod.Tile;
            this.progressBar5.ForegroundLeadingSize = 0;
            this.progressBar5.ForegroundPicture = ((System.Drawing.Image)(resources.GetObject("progressBar5.ForegroundPicture")));
            this.progressBar5.ForegroundTrailingSize = 0;
            this.progressBar5.Location = new System.Drawing.Point(5, 177);
            this.progressBar5.Marquee = Bornander.UI.ProgressBar.ProgressBar.MarqueeStyle.TileWrap;
            this.progressBar5.MarqueeWidth = 10;
            this.progressBar5.Maximum = 100;
            this.progressBar5.Minimum = 0;
            this.progressBar5.Name = "progressBar5";
            this.progressBar5.OverlayDrawMethod = Bornander.UI.ProgressBar.ProgressBar.DrawMethod.Stretch;
            this.progressBar5.OverlayLeadingSize = 0;
            this.progressBar5.OverlayPicture = null;
            this.progressBar5.OverlayTrailingSize = 0;
            this.progressBar5.Size = new System.Drawing.Size(188, 42);
            this.progressBar5.Type = Bornander.UI.ProgressBar.ProgressBar.BarType.Progress;
            this.progressBar5.Value = 0;
            // 
            // progressBar4
            // 
            this.progressBar4.BackgroundDrawMethod = Bornander.UI.ProgressBar.ProgressBar.DrawMethod.Stretch;
            this.progressBar4.BackgroundLeadingSize = 12;
            this.progressBar4.BackgroundPicture = ((System.Drawing.Image)(resources.GetObject("progressBar4.BackgroundPicture")));
            this.progressBar4.BackgroundTrailingSize = 12;
            this.progressBar4.ForegroundDrawMethod = Bornander.UI.ProgressBar.ProgressBar.DrawMethod.Tile;
            this.progressBar4.ForegroundLeadingSize = 0;
            this.progressBar4.ForegroundPicture = ((System.Drawing.Image)(resources.GetObject("progressBar4.ForegroundPicture")));
            this.progressBar4.ForegroundTrailingSize = 0;
            this.progressBar4.Location = new System.Drawing.Point(5, 32);
            this.progressBar4.Marquee = Bornander.UI.ProgressBar.ProgressBar.MarqueeStyle.TileWrap;
            this.progressBar4.MarqueeWidth = 10;
            this.progressBar4.Maximum = 100;
            this.progressBar4.Minimum = 0;
            this.progressBar4.Name = "progressBar4";
            this.progressBar4.OverlayDrawMethod = Bornander.UI.ProgressBar.ProgressBar.DrawMethod.Stretch;
            this.progressBar4.OverlayLeadingSize = 12;
            this.progressBar4.OverlayPicture = ((System.Drawing.Image)(resources.GetObject("progressBar4.OverlayPicture")));
            this.progressBar4.OverlayTrailingSize = 12;
            this.progressBar4.Size = new System.Drawing.Size(187, 23);
            this.progressBar4.Type = Bornander.UI.ProgressBar.ProgressBar.BarType.Marquee;
            this.progressBar4.Value = 0;
            // 
            // progressBar6
            // 
            this.progressBar6.BackgroundDrawMethod = Bornander.UI.ProgressBar.ProgressBar.DrawMethod.Tile;
            this.progressBar6.BackgroundLeadingSize = 0;
            this.progressBar6.BackgroundPicture = ((System.Drawing.Image)(resources.GetObject("progressBar6.BackgroundPicture")));
            this.progressBar6.BackgroundTrailingSize = 0;
            this.progressBar6.ForegroundDrawMethod = Bornander.UI.ProgressBar.ProgressBar.DrawMethod.Tile;
            this.progressBar6.ForegroundLeadingSize = 0;
            this.progressBar6.ForegroundPicture = ((System.Drawing.Image)(resources.GetObject("progressBar6.ForegroundPicture")));
            this.progressBar6.ForegroundTrailingSize = 0;
            this.progressBar6.Location = new System.Drawing.Point(5, 80);
            this.progressBar6.Marquee = Bornander.UI.ProgressBar.ProgressBar.MarqueeStyle.TileWrap;
            this.progressBar6.MarqueeWidth = 10;
            this.progressBar6.Maximum = 100;
            this.progressBar6.Minimum = 0;
            this.progressBar6.Name = "progressBar6";
            this.progressBar6.OverlayDrawMethod = Bornander.UI.ProgressBar.ProgressBar.DrawMethod.Stretch;
            this.progressBar6.OverlayLeadingSize = 4;
            this.progressBar6.OverlayPicture = null;
            this.progressBar6.OverlayTrailingSize = 4;
            this.progressBar6.Size = new System.Drawing.Size(187, 17);
            this.progressBar6.Type = Bornander.UI.ProgressBar.ProgressBar.BarType.Marquee;
            this.progressBar6.Value = 0;
            // 
            // progressBar8
            // 
            this.progressBar8.BackgroundDrawMethod = Bornander.UI.ProgressBar.ProgressBar.DrawMethod.Tile;
            this.progressBar8.BackgroundLeadingSize = 0;
            this.progressBar8.BackgroundPicture = ((System.Drawing.Image)(resources.GetObject("progressBar8.BackgroundPicture")));
            this.progressBar8.BackgroundTrailingSize = 0;
            this.progressBar8.ForegroundDrawMethod = Bornander.UI.ProgressBar.ProgressBar.DrawMethod.Tile;
            this.progressBar8.ForegroundLeadingSize = 0;
            this.progressBar8.ForegroundPicture = ((System.Drawing.Image)(resources.GetObject("progressBar8.ForegroundPicture")));
            this.progressBar8.ForegroundTrailingSize = 0;
            this.progressBar8.Location = new System.Drawing.Point(5, 223);
            this.progressBar8.Marquee = Bornander.UI.ProgressBar.ProgressBar.MarqueeStyle.TileWrap;
            this.progressBar8.MarqueeWidth = 10;
            this.progressBar8.Maximum = 100;
            this.progressBar8.Minimum = 0;
            this.progressBar8.Name = "progressBar8";
            this.progressBar8.OverlayDrawMethod = Bornander.UI.ProgressBar.ProgressBar.DrawMethod.Stretch;
            this.progressBar8.OverlayLeadingSize = 0;
            this.progressBar8.OverlayPicture = null;
            this.progressBar8.OverlayTrailingSize = 0;
            this.progressBar8.Size = new System.Drawing.Size(188, 42);
            this.progressBar8.Type = Bornander.UI.ProgressBar.ProgressBar.BarType.Progress;
            this.progressBar8.Value = 0;
            // 
            // progressBar9
            // 
            this.progressBar9.BackgroundDrawMethod = Bornander.UI.ProgressBar.ProgressBar.DrawMethod.Stretch;
            this.progressBar9.BackgroundLeadingSize = 12;
            this.progressBar9.BackgroundPicture = ((System.Drawing.Image)(resources.GetObject("progressBar9.BackgroundPicture")));
            this.progressBar9.BackgroundTrailingSize = 12;
            this.progressBar9.ForegroundDrawMethod = Bornander.UI.ProgressBar.ProgressBar.DrawMethod.Stretch;
            this.progressBar9.ForegroundLeadingSize = 12;
            this.progressBar9.ForegroundPicture = ((System.Drawing.Image)(resources.GetObject("progressBar9.ForegroundPicture")));
            this.progressBar9.ForegroundTrailingSize = 12;
            this.progressBar9.Location = new System.Drawing.Point(5, 127);
            this.progressBar9.Marquee = Bornander.UI.ProgressBar.ProgressBar.MarqueeStyle.BlockWrap;
            this.progressBar9.MarqueeWidth = 40;
            this.progressBar9.Maximum = 100;
            this.progressBar9.Minimum = 0;
            this.progressBar9.Name = "progressBar9";
            this.progressBar9.OverlayDrawMethod = Bornander.UI.ProgressBar.ProgressBar.DrawMethod.Stretch;
            this.progressBar9.OverlayLeadingSize = 12;
            this.progressBar9.OverlayPicture = ((System.Drawing.Image)(resources.GetObject("progressBar9.OverlayPicture")));
            this.progressBar9.OverlayTrailingSize = 12;
            this.progressBar9.Size = new System.Drawing.Size(187, 21);
            this.progressBar9.Type = Bornander.UI.ProgressBar.ProgressBar.BarType.Marquee;
            this.progressBar9.Value = 0;
            // 
            // progressBar10
            // 
            this.progressBar10.BackgroundDrawMethod = Bornander.UI.ProgressBar.ProgressBar.DrawMethod.Stretch;
            this.progressBar10.BackgroundLeadingSize = 12;
            this.progressBar10.BackgroundPicture = ((System.Drawing.Image)(resources.GetObject("progressBar10.BackgroundPicture")));
            this.progressBar10.BackgroundTrailingSize = 12;
            this.progressBar10.ForegroundDrawMethod = Bornander.UI.ProgressBar.ProgressBar.DrawMethod.Stretch;
            this.progressBar10.ForegroundLeadingSize = 12;
            this.progressBar10.ForegroundPicture = ((System.Drawing.Image)(resources.GetObject("progressBar10.ForegroundPicture")));
            this.progressBar10.ForegroundTrailingSize = 12;
            this.progressBar10.Location = new System.Drawing.Point(5, 150);
            this.progressBar10.Marquee = Bornander.UI.ProgressBar.ProgressBar.MarqueeStyle.Wave;
            this.progressBar10.MarqueeWidth = 40;
            this.progressBar10.Maximum = 100;
            this.progressBar10.Minimum = 0;
            this.progressBar10.Name = "progressBar10";
            this.progressBar10.OverlayDrawMethod = Bornander.UI.ProgressBar.ProgressBar.DrawMethod.Stretch;
            this.progressBar10.OverlayLeadingSize = 12;
            this.progressBar10.OverlayPicture = ((System.Drawing.Image)(resources.GetObject("progressBar10.OverlayPicture")));
            this.progressBar10.OverlayTrailingSize = 12;
            this.progressBar10.Size = new System.Drawing.Size(187, 21);
            this.progressBar10.Type = Bornander.UI.ProgressBar.ProgressBar.BarType.Marquee;
            this.progressBar10.Value = 0;
            // 
            // marqueeTimer
            // 
            this.marqueeTimer.Interval = 25;
            this.marqueeTimer.Tick += new System.EventHandler(this.marqueeTimer_Tick);
            // 
            // TestForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(240, 268);
            this.Controls.Add(this.progressBar10);
            this.Controls.Add(this.progressBar9);
            this.Controls.Add(this.progressBar8);
            this.Controls.Add(this.progressBar6);
            this.Controls.Add(this.progressBar4);
            this.Controls.Add(this.progressBar5);
            this.Controls.Add(this.progressBar3);
            this.Controls.Add(this.progressBar2);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.trackBar1);
            this.Menu = this.mainMenu1;
            this.Name = "TestForm";
            this.Text = "Custom Scrollbar Test";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.MenuItem menuItemFile;
        private System.Windows.Forms.MenuItem menuItemExit;
        private System.Windows.Forms.TrackBar trackBar1;
        private Bornander.UI.ProgressBar.ProgressBar progressBar1;
        private Bornander.UI.ProgressBar.ProgressBar progressBar2;
        private Bornander.UI.ProgressBar.ProgressBar progressBar3;
        private Bornander.UI.ProgressBar.ProgressBar progressBar5;
        private Bornander.UI.ProgressBar.ProgressBar progressBar4;
        private Bornander.UI.ProgressBar.ProgressBar progressBar6;
        private Bornander.UI.ProgressBar.ProgressBar progressBar8;
        private Bornander.UI.ProgressBar.ProgressBar progressBar9;
        private Bornander.UI.ProgressBar.ProgressBar progressBar10;
        private System.Windows.Forms.Timer marqueeTimer;
    }
}

