﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace ProgressBar
{
    public partial class SuperProgress : UserControl
    {
        
        public SuperProgress()
        {
            InitializeComponent();
        }
        #region properties

        #region label properties
        private string _LbLCaption;
        public string LbLCaption
        { 
          get{return _LbLCaption;}
          set 
          {
              _LbLCaption = value;
              label1.Text = _LbLCaption; 
          }
        }

        private Font _font;
        public Font LbLFont
        {
            get { return _font; }
            set { label1.Font = value; }
        }

        private Color _lblForeCOlor;
        public Color LbLForeColor
        {
            get { return _lblForeCOlor; }
            set { label1.ForeColor = value; }
        }
        private Color _lblBackColor;
        public Color LbLBackColor
        {
            get { return _lblBackColor; }
            set { label1.BackColor = value; }
        }
        #endregion

        #region progress bar
        private int _minPRGBAR;
        public int minPRGBAR
        {
            get { return _minPRGBAR; }
            set 
            {
                _minPRGBAR = value;
                progressBar1.Minimum = _minPRGBAR;
            }
        }

        private int _maxPRGBAR;
        public int maxPRGBAR
        {
            get { return _maxPRGBAR; }
            set 
            {  _maxPRGBAR = value;            
                progressBar1.Maximum = _maxPRGBAR;
            }
        }
        private int _valuePRGBAR;
        public int valuePRGBAR
        {
            get { return _valuePRGBAR; }
            set 
            {
                _valuePRGBAR = value;
                progressBar1.Value = _valuePRGBAR;
            }
        }
        #endregion 

        #endregion

        #region methods
        public void write(string text, int prgNumValue)
        {
            LbLCaption = text;
            valuePRGBAR = prgNumValue;
        }
        #endregion
    }
}