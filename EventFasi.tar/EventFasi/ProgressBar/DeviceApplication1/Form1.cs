﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using testEvent;

namespace DeviceApplication1
{
    public partial class Form1 : Form
    {
        int i = 0;
        cEventRaise k = new cEventRaise();   
        public Form1()
        {
            InitializeComponent();
            superProgress1.maxPRGBAR = 10;            
        }

        private void menuItem1_Click(object sender, EventArgs e)
        {
            k._event += new cEventRaise.skata(k_sk);
            k.loop();
            k._event -= new cEventRaise.skata(k_sk);
            //timer1.Enabled = true;
        }
        void k_sk(string str)
        {
            if (Convert.ToInt32(str) == 10)
            {
                timer1.Enabled = false;                
                superProgress1.write("", 0);
                return;
            }
            
            superProgress1.write(str, Convert.ToInt32(str));
            return;
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            
            if (superProgress1.valuePRGBAR == 100)
            {
                timer1.Enabled = false;
                i=0;
                superProgress1.write("", i);
                return;
            }
            i+=10;   
            superProgress1.write(i.ToString(), i);
        }
    }
}