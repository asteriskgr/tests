﻿namespace DeviceApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.menuItem1 = new System.Windows.Forms.MenuItem();
            this.timer1 = new System.Windows.Forms.Timer();
            this.superProgress1 = new ProgressBar.SuperProgress();          
            this.SuspendLayout();
            // 
            // mainMenu1
            // 
            this.mainMenu1.MenuItems.Add(this.menuItem1);
            // 
            // menuItem1
            // 
            this.menuItem1.Text = "progress";
            this.menuItem1.Click += new System.EventHandler(this.menuItem1_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // superProgress1
            // 
            this.superProgress1.LbLBackColor = System.Drawing.Color.Empty;
            this.superProgress1.LbLCaption = null;
            this.superProgress1.LbLFont = null;
            this.superProgress1.LbLForeColor = System.Drawing.Color.Empty;
            this.superProgress1.Location = new System.Drawing.Point(1, 201);
            this.superProgress1.maxPRGBAR = 0;
            this.superProgress1.minPRGBAR = 0;
            this.superProgress1.Name = "superProgress1";
            this.superProgress1.Size = new System.Drawing.Size(237, 43);
            this.superProgress1.TabIndex = 0;
            this.superProgress1.valuePRGBAR = 0;          
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(240, 268);
            this.Controls.Add(this.superProgress1);
            this.Menu = this.mainMenu1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private ProgressBar.SuperProgress superProgress1;
        private System.Windows.Forms.MenuItem menuItem1;
        private System.Windows.Forms.Timer timer1;       
    }
}

