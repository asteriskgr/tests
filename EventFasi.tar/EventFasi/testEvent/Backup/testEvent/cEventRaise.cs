﻿using System;
using System.Collections.Generic;
using System.Text;

namespace testEvent
{
    public  class cEventRaise
    {
        private string str;
        public delegate void skata(string str);
        public event skata _event;
        public string takeStr
        {
            get { return str; }
            set 
            {                
                str = value;
                _loop(str); 
            }
        }
        private void _loop(string pp)
        {
            if (_event != null)
                _event(pp);
        }
        public void loop()
        {
            for (int i = 0; i < 5; i++)
            {
                takeStr = i.ToString();                               
            }
        }
    }
}
