﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace testEvent
{
    public partial class Form1 : Form
    {
        cEventRaise k = new cEventRaise();        

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            k._event += new cEventRaise.skata(k_sk);
            k.loop();
        }
        void k_sk(string str)
        {
            string kk = str;
        }
    }
}